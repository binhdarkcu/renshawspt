<?php 
/**
 * 
 * MemberMouse(TM) (http://www.membermouse.com)
 * (c) MemberMouse, LLC. All rights reserved.
 */
?>

<div id="mm-form-container">
<input id="mm-gift-link" type="text" readonly value="<?php echo $p->link ?>" onclick="jQuery('#mm-gift-link').focus(); jQuery('#mm-gift-link').select();" style="width:400px; font-family:courier; font-size:11px;" />
</div>