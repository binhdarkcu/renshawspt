<?php
/**
 * 
 * MemberMouse(TM) (http://www.membermouse.com)
 * (c) MemberMouse, LLC. All rights reserved.
 */
?>

<div id="mm-limelight-shipping-methods-dialog"></div>

<script>jQuery(function(){jQuery("#mm-limelight-shipping-methods-dialog").dialog({autoOpen: false});});</script>