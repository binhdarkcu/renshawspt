<?php 
/**
 *
 * MemberMouse(TM) (http://www.membermouse.com)
 * (c) MemberMouse, LLC. All rights reserved.
 */
?>
	<tr>
		<td>
			<div id='cp_types'  style='width: 220px'>
				<?php echo $p->options; ?>
				<input type='hidden' name='save-mm-corepages[ref_type]' value='<?php echo $p->ref_type; ?>' />
			</div>	
		</td>
	</tr>
