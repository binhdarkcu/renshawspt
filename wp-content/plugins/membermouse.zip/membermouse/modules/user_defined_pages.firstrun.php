<?php
/**
 * 
 * MemberMouse(TM) (http://www.membermouse.com)
 * (c) MemberMouse, LLC. All rights reserved.
 */
?>

<div id="mm-page-dialog"></div>

<script>jQuery(function(){jQuery("#mm-page-dialog").dialog({autoOpen: false});});
</script>