<?php
/**
 * 
 * MemberMouse(TM) (http://www.membermouse.com)
 * (c) MemberMouse, LLC. All rights reserved.
 */
?>
<div id="mm-api-keys-dialog"></div>

<script>jQuery(function(){jQuery("#mm-api-keys-dialog").dialog({autoOpen: false});});
</script>