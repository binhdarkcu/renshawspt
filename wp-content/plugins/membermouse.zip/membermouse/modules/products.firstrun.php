<?php
/**
 * 
 * MemberMouse(TM) (http://www.membermouse.com)
 * (c) MemberMouse, LLC. All rights reserved.
 */
?>
<div id="mm-products-dialog"></div>
<div id="mm-purchaselinks-dialog"></div>

<script>
  jQuery(document).ready(function(){
    jQuery("#mm-products-dialog").dialog({autoOpen: false});
    jQuery("#mm-purchaselinks-dialog").dialog({autoOpen: false});
  });
</script>