<?php
/**
 * 
 * MemberMouse(TM) (http://www.membermouse.com)
 * (c) MemberMouse, LLC. All rights reserved.
 */
?>

<!-- Employees Dialog -->
<div id="mm-employee-accounts-dialog"></div>

<script>jQuery(function(){jQuery("#mm-employee-accounts-dialog").dialog({autoOpen: false});});
</script>