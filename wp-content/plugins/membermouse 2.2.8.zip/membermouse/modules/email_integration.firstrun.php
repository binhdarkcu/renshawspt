<?php
/**
 * 
 * MemberMouse(TM) (http://www.membermouse.com)
 * (c) MemberMouse, LLC. All rights reserved.
 */
?>
<div id="mm-bundle-mapping-dialog"></div>

<script>
jQuery(function(){jQuery("#mm-bundle-mapping-dialog").dialog({autoOpen: false});});
</script>