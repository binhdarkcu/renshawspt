<?php
/**
 * 
 * MemberMouse(TM) (http://www.membermouse.com)
 * (c) MemberMouse, LLC. All rights reserved.
 */
?>

<div id="mm-push-notification-dialog"></div>

<script>
  jQuery(document).ready(function(){
    jQuery("#mm-push-notification-dialog").dialog({autoOpen: false});  
  });
</script>