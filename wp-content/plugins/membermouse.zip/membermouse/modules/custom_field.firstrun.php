<?php
/**
 * 
 * MemberMouse(TM) (http://www.membermouse.com)
 * (c) MemberMouse, LLC. All rights reserved.
 */
?>
<div id="mm-custom-fields-dialog"></div>
<div id="mm-smarttags-dialog"></div>

<script>
  jQuery(function(){
    jQuery("#mm-custom-fields-dialog").dialog({autoOpen: false});
    jQuery("#mm-smarttags-dialog").dialog({autoOpen: false});
  });
</script>