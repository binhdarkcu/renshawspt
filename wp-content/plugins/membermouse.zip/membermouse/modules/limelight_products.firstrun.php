<?php
/**
 * 
 * MemberMouse(TM) (http://www.membermouse.com)
 * (c) MemberMouse, LLC. All rights reserved.
 */
?>

<div id="mm-limelight-products-dialog"></div>

<script>jQuery(function(){jQuery("#mm-limelight-products-dialog").dialog({autoOpen: false});});</script>