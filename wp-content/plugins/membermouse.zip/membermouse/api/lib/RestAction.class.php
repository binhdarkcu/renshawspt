<?php
/**
  * Class RestAction
  * Inteface for a possible action for to be taken
  */
interface RestAction {

}
?>