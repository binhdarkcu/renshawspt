<?php
/**
 * 
 * MemberMouse(TM) (http://www.membermouse.com)
 * (c) MemberMouse, LLC. All rights reserved.
 */
?>

<div id="mm-create-member-dialog"></div>

<script>
jQuery(function(){jQuery("#mm-create-member-dialog").dialog({autoOpen: false});});
</script>