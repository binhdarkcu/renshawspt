<?php
/**
 * 
 * MemberMouse(TM) (http://www.membermouse.com)
 * (c) MemberMouse, LLC. All rights reserved.
 */
?>

<div id="mm-coupons-dialog"></div>

<script>jQuery(function(){jQuery("#mm-coupons-dialog").dialog({autoOpen: false});});
</script>