<?php
/**
 * 
 * MemberMouse(TM) (http://www.membermouse.com)
 * (c) MemberMouse, LLC. All rights reserved.
 */
?>

<div id="mm-bundles-dialog"></div>
<div id="mm-purchaselinks-dialog"></div>

<script>
  jQuery(function(){
    jQuery("#mm-bundles-dialog").dialog({autoOpen: false});
    jQuery("#mm-purchaselinks-dialog").dialog({autoOpen: false});
  });
</script>