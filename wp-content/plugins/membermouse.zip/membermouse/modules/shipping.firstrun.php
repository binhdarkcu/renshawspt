<?php
/**
 * 
 * MemberMouse(TM) (http://www.membermouse.com)
 * (c) MemberMouse, LLC. All rights reserved.
 */
?>
<!-- Api Dialog -->
<div id="mm-shipping-dialog"></div>

<script>jQuery(function(){jQuery("#mm-shipping-dialog").dialog({autoOpen: false});});
</script>