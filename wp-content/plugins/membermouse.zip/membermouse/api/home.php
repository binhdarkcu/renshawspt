<html>
<body>
<h1>MemberMouse API</h1>
<p>The MemberMouse API is active.</p>
</body>
</html>
